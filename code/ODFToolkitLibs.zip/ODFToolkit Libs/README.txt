
JLOP Chapter 17. Simple ODF

From the website:

  Java LibreOffice Programming
  http://fivedots.coe.psu.ac.th/~ad/jlop

  Dr. Andrew Davison
  Dept. of Computer Engineering
  Prince of Songkla University
  Hat Yai, Songkhla 90112, Thailand
  E-mail: ad@fivedots.coe.psu.ac.th


If you use this code, please mention my name, and include a link
to the website.

Thanks,
  Andrew

============================

This directory contains all the libraries I needed in order to get my ODFToolkit
examples to compile and run.

1) ODFToolkit
   odftoolkit-0.6.1-incubating-bin.zip
   odftoolkit-0.6.1-incubating-doc.zip
      -- unzipped to d:\odftoolkit 
      -- note: these zip files actually contain v.8.10

2) Xerces-J-bin.2.11.0.zip
      -- unzipped to d:\xerces-2_11_0

3) apache-jena-2.12.1.zip
      -- unzipped to d:\apache-jena-2.12.1
      -- note: the v3.1.1 of Apache Jena would not work with ODFToolkit

4) Assorted others:

   java-rdfa-0.5-20100701.145737-3.jar
      -- stored in d:\odftoolkit 

   iri-0.8.zip
       -- unzipped, and JAR stored in d:\apache-jena-2.12.1\lib

   icu4j-54.1.1.jar
       -- stored in d:\apache-jena-2.12.1\lib

   commons-validator-1.4.1-bin.zip
       -- stored in d:\apache-jena-2.12.1\lib


At this point, your d:\ drive should have three new folders:
  d:\odftoolkit
  d:\xerces-2_11_0
  d:\apache-jena-2.12.1

=================================
Last updated: 13th January 2017
